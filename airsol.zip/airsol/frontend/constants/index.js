import { PublicKey } from "@solana/web3.js";

export const AIRSOL_PROGRAM_PUBKEY = new PublicKey("J5yzCZrNZJR6K5FUwwZ2SzjTvg8DzomcYqcaZJm27Y6v");
